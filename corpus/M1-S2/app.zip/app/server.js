const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const path = require('path');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const app = express();
const db = new Database('app.db');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: 'secretkey',
  resave: false,
  saveUninitialized: false
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

db.prepare(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE,
  password TEXT,
  role TEXT
)`).run();

db.prepare(`
CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  capacity INTEGER,
  equipment TEXT,
  photo TEXT
)`).run();

db.prepare(`
CREATE TABLE IF NOT EXISTS reservations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  room_id INTEGER,
  start_time TEXT,
  end_time TEXT
)`).run();

db.prepare(`
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  message TEXT,
  created_at TEXT
)`).run();

const admin = db.prepare('SELECT * FROM users WHERE email = ?').get('admin@example.com');

if (!admin) {
  const hash = bcrypt.hashSync('admin123', 10);

  db.prepare(`
    INSERT INTO users (email, password, role)
    VALUES (?, ?, ?)
  `).run('admin@example.com', hash, 'manager');
}

const roomCount = db.prepare('SELECT COUNT(*) as total FROM rooms').get();

if (roomCount.total === 0) {
  const insert = db.prepare(`
    INSERT INTO rooms (name, capacity, equipment, photo)
    VALUES (?, ?, ?, ?)
  `);

  insert.run('Salle Alpha', 8, 'TV, HDMI, WiFi', 'https://picsum.photos/400/200?1');
  insert.run('Salle Beta', 12, 'Projecteur, Tableau', 'https://picsum.photos/400/200?2');
  insert.run('Salle Gamma', 20, 'Visioconférence, TV', 'https://picsum.photos/400/200?3');
}

app.use((req, res, next) => {
  res.locals.user = req.session.user;
  next();
});

function auth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

function manager(req, res, next) {
  if (!req.session.user || req.session.user.role !== 'manager') {
    return res.send('Accès refusé');
  }
  next();
}

app.get('/', (req, res) => {
  const rooms = db.prepare('SELECT * FROM rooms').all();
  res.render('index', { rooms });
});

app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', (req, res) => {
  const { email, password } = req.body;
  const hash = bcrypt.hashSync(password, 10);

  try {
    db.prepare(`
      INSERT INTO users (email, password, role)
      VALUES (?, ?, ?)
    `).run(email, hash, 'user');

    res.redirect('/login');
  } catch {
    res.send('Email déjà utilisé');
  }
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  const { email, password } = req.body;

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

  if (!user) return res.send('Utilisateur introuvable');

  const valid = bcrypt.compareSync(password, user.password);

  if (!valid) return res.send('Mot de passe invalide');

  req.session.user = {
    id: user.id,
    email: user.email,
    role: user.role
  };

  res.redirect('/');
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

app.get('/room/:id', auth, (req, res) => {
  const room = db.prepare('SELECT * FROM rooms WHERE id = ?').get(req.params.id);

  const reservations = db.prepare(`
    SELECT reservations.*, users.email
    FROM reservations
    JOIN users ON users.id = reservations.user_id
    WHERE room_id = ?
    ORDER BY start_time
  `).all(req.params.id);

  res.render('room', { room, reservations });
});

app.post('/reserve/:roomId', auth, (req, res) => {
  const { start_time } = req.body;

  const start = new Date(start_time);
  const end = new Date(start.getTime() + 60 * 60 * 1000);

  const existing = db.prepare(`
    SELECT * FROM reservations
    WHERE room_id = ?
    AND start_time = ?
  `).get(req.params.roomId, start.toISOString());

  if (existing) {
    return res.send('Créneau déjà réservé');
  }

  db.prepare(`
    INSERT INTO reservations (user_id, room_id, start_time, end_time)
    VALUES (?, ?, ?, ?)
  `).run(
    req.session.user.id,
    req.params.roomId,
    start.toISOString(),
    end.toISOString()
  );

  db.prepare(`
    INSERT INTO notifications (user_id, message, created_at)
    VALUES (?, ?, ?)
  `).run(
    req.session.user.id,
    'Votre réservation approche',
    new Date().toISOString()
  );

  res.redirect('/room/' + req.params.roomId);
});

app.post('/reservation/delete/:id', auth, (req, res) => {
  const reservation = db.prepare(`
    SELECT * FROM reservations WHERE id = ?
  `).get(req.params.id);

  if (
    reservation.user_id !== req.session.user.id &&
    req.session.user.role !== 'manager'
  ) {
    return res.send('Interdit');
  }

  db.prepare('DELETE FROM reservations WHERE id = ?').run(req.params.id);

  res.redirect('back');
});

app.get('/reservation/edit/:id', auth, (req, res) => {
  const reservation = db.prepare(`
    SELECT * FROM reservations WHERE id = ?
  `).get(req.params.id);

  res.render('editReservation', { reservation });
});

app.post('/reservation/edit/:id', auth, (req, res) => {
  const start = new Date(req.body.start_time);
  const end = new Date(start.getTime() + 60 * 60 * 1000);

  db.prepare(`
    UPDATE reservations
    SET start_time = ?, end_time = ?
    WHERE id = ?
  `).run(start.toISOString(), end.toISOString(), req.params.id);

  res.redirect('/');
});

app.get('/manager', auth, manager, (req, res) => {
  const rooms = db.prepare('SELECT * FROM rooms').all();

  const stats = db.prepare(`
    SELECT rooms.name, COUNT(reservations.id) as total
    FROM rooms
    LEFT JOIN reservations ON rooms.id = reservations.room_id
    GROUP BY rooms.id
  `).all();

  res.render('manager', { rooms, stats });
});

app.post('/manager/room/add', auth, manager, (req, res) => {
  const { name, capacity, equipment, photo } = req.body;

  db.prepare(`
    INSERT INTO rooms (name, capacity, equipment, photo)
    VALUES (?, ?, ?, ?)
  `).run(name, capacity, equipment, photo);

  res.redirect('/manager');
});

app.post('/manager/room/delete/:id', auth, manager, (req, res) => {
  db.prepare('DELETE FROM rooms WHERE id = ?').run(req.params.id);
  res.redirect('/manager');
});

app.get('/notifications', auth, (req, res) => {
  const notifications = db.prepare(`
    SELECT * FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
  `).all(req.session.user.id);

  res.render('notifications', { notifications });
});

app.listen(3000, () => {
  console.log('Serveur lancé sur http://localhost:3000');
});
