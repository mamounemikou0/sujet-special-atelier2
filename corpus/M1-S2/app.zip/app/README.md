# Application de réservation de salles

## Installation

```bash
npm install
node server.js
```

Application disponible sur :
http://localhost:3000

## Compte gestionnaire par défaut

- Email : admin@example.com
- Mot de passe : admin123

## Fonctionnalités

- Inscription / connexion
- Gestion des salles
- Réservations par créneaux d'1h
- Gestionnaire avec dashboard
- Notifications simulées
